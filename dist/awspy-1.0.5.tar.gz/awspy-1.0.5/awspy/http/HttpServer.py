'''
Created on 2010-11-4

@author: Administrator
'''

class HttpServer(object):
    '''
    classdocs
    '''


    def __init__(self):
        '''
        Constructor
        '''
        
    
        