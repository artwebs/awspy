class Db(object):
    '''
    classdocs
    '''
    conn=None
    cursor=None
    connstr=None
    host=None
    user=None
    passwd=None
    db=None
    

    def __init__(self,connstr=None,host=None,user=None,passwd=None,db=None,port=None):
        self.connstr=connstr
        self.host=host
        self.user=user
        self.passwd=passwd
        self.db=db
        self.port=port
        
    def getCursor(self):
        pass
    
    def runExecute(self,sql):
        print sql
        rs=False
        self.getCursor()
        self.cursor.execute(sql)
        rscount=self.cursor.rowcount
        self.conn.commit()
        self.closeCursor();
        if rscount>0:
            rs=True
        return rs
    
    def getQuery(self,sql):
        print sql
        self.getCursor()
        self.cursor.execute(sql) 
        rs = self.cursor.fetchall() 
        self.closeCursor();
        return rs
    
    def closeCursor(self):
        self.cursor.close();
        self.conn.close(); 
        