'''
Created on 2010-11-5

@author: Administrator
'''

class Servlet(object):
    '''
    classdocs
    '''


    def __init__(self):
        '''
        Constructor
        '''
    
        