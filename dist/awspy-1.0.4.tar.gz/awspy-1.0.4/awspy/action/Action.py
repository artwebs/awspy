'''
Created on 2012-8-15

@author: artwebs
'''

class Action(object):
    '''
    classdocs
    '''

    def __init__(self):
        '''
        Constructor
        '''
        