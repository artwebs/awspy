'''
Created on 2010-11-8

@author: Administrator
'''

class OracleModel(object):
    '''
    classdocs
    '''


    def __init__(self):
        '''
        Constructor
        '''
        