'''
Created on 2010-11-8

@author: Administrator
'''

class Model(object):
    
    '''
    classdocs
    '''


    def __init__(self,top=None,tableName=None):
        '''
        Constructo
        '''
    
    def getSelectResult(self,fvs=None,where=None,tableName=None):
        pass
    
    def getInsertResult(self,fvs=None,where=None,tableName=None):
        pass
    
    def getUpdateResult(self,fvs=None,where=None,tableName=None):
        pass
    
    def getDeleteResult(self,where=None,tableName=None):
        pass